DKODER STUDENT WEBSITE REDESIGN — QUICK START

1. Extract this ZIP file.
2. Open the dkoder-rebuilt folder.
3. Double-click index.html to open it in Chrome or Edge.
4. Use the header to open seven separate pages: Home, Learn, Hackathons, Internships, Jobs, For Colleges, and Apply for MOU.
5. The Go to Dashboard button opens https://dkoder.co.in/.

DESIGN NOTES
- The Home hero uses black text on a bright yellow side and a purple side with a custom illustration of three student builders holding laptops.
- Each page begins with a near-full-screen hero. Scroll down within a page for its roadmap, cards, and checklists. Use the header to switch to another page.
- Card hover effects and the Home mini-mission checklist are interactive.
- Internet is needed for remote student photos and Google Fonts. The custom illustrated student team is drawn directly in the HTML.
- This is a student-made redesign concept, not the official Dkoder website. It does not submit information or connect to an AI service. Official Dkoder link: https://dkoder.co.in/
